from django.apps import AppConfig


class GoologinConfig(AppConfig):
    name = 'goologin'
